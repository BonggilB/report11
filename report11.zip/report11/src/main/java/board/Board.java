package board;

public class Board {
	private int Num;
	private String title;
	private String content;
	private String docDate;
	private boolean docFlag;
	
	public int getNum() {
		return Num;
	}
	public void setNum(int num) {
		Num = num;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getDocDate() {
		return docDate;
	}
	public void setDocDate(String docDate) {
		this.docDate = docDate;
	}
	public boolean isDocFlag() {
		return docFlag;
	}
	public void setDocFlag(boolean docFlag) {
		this.docFlag = docFlag;
	}
	
}
